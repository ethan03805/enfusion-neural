// Offline generated-shader backend. Explicit RGBA8 or lighting FP32 records; no engine hook.
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using Microsoft::WRL::ComPtr;
using Clock = std::chrono::steady_clock;
void check(HRESULT hr) { if (FAILED(hr)) throw std::runtime_error("HRESULT " + std::to_string(static_cast<unsigned long>(hr))); }
double elapsed(Clock::time_point t) { return std::chrono::duration<double, std::milli>(Clock::now()-t).count(); }
std::string utf8(const wchar_t* str) {
 int size = WideCharToMultiByte(CP_UTF8,0,str,-1,nullptr,0,nullptr,nullptr);
 std::string value(size, '\0');
 WideCharToMultiByte(CP_UTF8,0,str,-1,value.data(),size,nullptr,nullptr);
 value.pop_back(); return value;
}
int wmain(int argc, wchar_t** argv) {
 try {
  if(argc != 9 && argc != 10) { std::cerr << "Usage: enr_gpu input.bin output.bin benchmark.json width height model.hlsl warmup samples [lighting20|lighting17|lighting3]\n"; return 2; }
  const auto setupStart=Clock::now();
  const std::wstring mode=argc==10 ? argv[9] : L"rgba8";
  UINT inputStride=4, outputStride=4;
  if(argc==10) {
   UINT features=mode==L"lighting20" ? 20 : mode==L"lighting17" ? 17 : mode==L"lighting3" ? 3 : 0;
   if(!features) throw std::runtime_error("Unsupported record mode");
   inputStride=(features+5)*sizeof(float); outputStride=7*sizeof(float);
  }
  auto number=[](const wchar_t* text) {
   std::wstring value(text);
   if(value.empty() || value.find_first_not_of(L"0123456789")!=std::wstring::npos)
    throw std::runtime_error("Expected unsigned decimal argument");
   return std::stoull(value);
  };
  const auto widthValue=number(argv[4]), heightValue=number(argv[5]);
  if(!widthValue || !heightValue || widthValue>16384 || heightValue>16384 || widthValue*heightValue>65535ull*256)
   throw std::runtime_error("Invalid dimensions");
  const auto warmupValue=number(argv[7]), sampleValue=number(argv[8]);
  if(warmupValue>100 || sampleValue<1 || sampleValue>1000)
   throw std::runtime_error("Invalid warmup or sample count");
  UINT width=static_cast<UINT>(widthValue), height=static_cast<UINT>(heightValue), count=width*height;
  const size_t inputBytes=static_cast<size_t>(count)*inputStride, outputBytes=static_cast<size_t>(count)*outputStride;
  std::ifstream in(std::filesystem::path(argv[1]), std::ios::binary | std::ios::ate);
  if(!in) throw std::runtime_error("Cannot open input");
  auto size=in.tellg();
  if(size!=static_cast<std::streamoff>(inputBytes)) throw std::runtime_error("Input size differs from dimensions and record mode");
  std::vector<uint8_t> pixels(static_cast<size_t>(size));
  in.seekg(0); in.read(reinterpret_cast<char*>(pixels.data()),pixels.size());
  if(!in) throw std::runtime_error("Incomplete input read");
  ComPtr<IDXGIFactory6> factory;
  check(CreateDXGIFactory1(IID_PPV_ARGS(&factory)));
  ComPtr<IDXGIAdapter1> adapter;
  ComPtr<ID3D12Device> device;
  DXGI_ADAPTER_DESC1 adapterDesc{};
  for(UINT i=0; ;++i) {
   ComPtr<IDXGIAdapter1> candidate;
   HRESULT hr=factory->EnumAdapterByGpuPreference(i,DXGI_GPU_PREFERENCE_HIGH_PERFORMANCE,IID_PPV_ARGS(&candidate));
   if(hr==DXGI_ERROR_NOT_FOUND) break;
   check(hr);
   DXGI_ADAPTER_DESC1 desc{}; check(candidate->GetDesc1(&desc));
   // Some hosted environments expose Basic Render Driver without the software flag.
   if((desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) ||
      std::wstring(desc.Description)==L"Microsoft Basic Render Driver") continue;
   if(SUCCEEDED(D3D12CreateDevice(candidate.Get(),D3D_FEATURE_LEVEL_12_0,IID_PPV_ARGS(&device)))) {
    adapter=candidate; adapterDesc=desc; break;
   }
  }
  if(!device) throw std::runtime_error("No hardware D3D12 FL12_0 adapter");
  ComPtr<ID3D12CommandQueue> queue;
  D3D12_COMMAND_QUEUE_DESC queueDesc{}; queueDesc.Type=D3D12_COMMAND_LIST_TYPE_DIRECT;
  check(device->CreateCommandQueue(&queueDesc,IID_PPV_ARGS(&queue)));
  ComPtr<ID3D12CommandAllocator> allocator;
  check(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator)));
  ComPtr<ID3D12GraphicsCommandList> list;
  check(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator.Get(),nullptr,IID_PPV_ARGS(&list)));
  auto buffer=[&](UINT64 bytes,D3D12_HEAP_TYPE type,D3D12_RESOURCE_STATES state,D3D12_RESOURCE_FLAGS flags=D3D12_RESOURCE_FLAG_NONE) {
   D3D12_HEAP_PROPERTIES heap{}; heap.Type=type; heap.CreationNodeMask=heap.VisibleNodeMask=1;
   D3D12_RESOURCE_DESC desc{}; desc.Dimension=D3D12_RESOURCE_DIMENSION_BUFFER; desc.Width=bytes;
   desc.Height=1; desc.DepthOrArraySize=desc.MipLevels=1; desc.SampleDesc.Count=1;
   desc.Layout=D3D12_TEXTURE_LAYOUT_ROW_MAJOR; desc.Flags=flags;
   ComPtr<ID3D12Resource> result;
   check(device->CreateCommittedResource(&heap,D3D12_HEAP_FLAG_NONE,&desc,state,nullptr,IID_PPV_ARGS(&result)));
   return result;
  };
  auto upload=buffer(pixels.size(),D3D12_HEAP_TYPE_UPLOAD,D3D12_RESOURCE_STATE_GENERIC_READ);
  auto source=buffer(pixels.size(),D3D12_HEAP_TYPE_DEFAULT,D3D12_RESOURCE_STATE_COPY_DEST);
  auto target=buffer(outputBytes,D3D12_HEAP_TYPE_DEFAULT,D3D12_RESOURCE_STATE_UNORDERED_ACCESS,D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
  auto readback=buffer(outputBytes,D3D12_HEAP_TYPE_READBACK,D3D12_RESOURCE_STATE_COPY_DEST);
  D3D12_RANGE noRead{0,0}; void* mapped=nullptr;
  check(upload->Map(0,&noRead,&mapped)); memcpy(mapped,pixels.data(),pixels.size()); upload->Unmap(0,nullptr);
  ComPtr<ID3DBlob> shaderBlob, errors, rootBlob;
  HRESULT hr=D3DCompileFromFile(argv[6],nullptr,nullptr,"main","cs_5_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&shaderBlob,&errors);
  if(FAILED(hr) && errors) std::cerr << static_cast<char*>(errors->GetBufferPointer());
  check(hr);
  D3D12_ROOT_PARAMETER params[3]{};
  params[0].ParameterType=D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS; params[0].Constants.Num32BitValues=3;
  params[1].ParameterType=D3D12_ROOT_PARAMETER_TYPE_SRV;
  params[2].ParameterType=D3D12_ROOT_PARAMETER_TYPE_UAV;
  D3D12_ROOT_SIGNATURE_DESC rootDesc{}; rootDesc.NumParameters=3; rootDesc.pParameters=params;
  check(D3D12SerializeRootSignature(&rootDesc,D3D_ROOT_SIGNATURE_VERSION_1,&rootBlob,&errors));
  ComPtr<ID3D12RootSignature> root;
  check(device->CreateRootSignature(0,rootBlob->GetBufferPointer(),rootBlob->GetBufferSize(),IID_PPV_ARGS(&root)));
  D3D12_COMPUTE_PIPELINE_STATE_DESC psoDesc{}; psoDesc.pRootSignature=root.Get();
  psoDesc.CS={shaderBlob->GetBufferPointer(),shaderBlob->GetBufferSize()};
  ComPtr<ID3D12PipelineState> pso;
  check(device->CreateComputePipelineState(&psoDesc,IID_PPV_ARGS(&pso)));
  const UINT warmup=static_cast<UINT>(warmupValue), samples=static_cast<UINT>(sampleValue), runs=warmup+samples;
  const UINT queryCount=2*runs+4;
  D3D12_QUERY_HEAP_DESC queryDesc{}; queryDesc.Type=D3D12_QUERY_HEAP_TYPE_TIMESTAMP; queryDesc.Count=queryCount;
  ComPtr<ID3D12QueryHeap> queries; check(device->CreateQueryHeap(&queryDesc,IID_PPV_ARGS(&queries)));
  auto timestamps=buffer(queryCount*sizeof(UINT64),D3D12_HEAP_TYPE_READBACK,D3D12_RESOURCE_STATE_COPY_DEST);
  UINT64 frequency; check(queue->GetTimestampFrequency(&frequency));
  auto stamp=[&](UINT index) { list->EndQuery(queries.Get(),D3D12_QUERY_TYPE_TIMESTAMP,index); };
  auto transition=[&](ID3D12Resource* resource,D3D12_RESOURCE_STATES before,D3D12_RESOURCE_STATES after) {
   D3D12_RESOURCE_BARRIER b{}; b.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
   b.Transition={resource,D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES,before,after}; list->ResourceBarrier(1,&b);
  };
  const double setupMs=elapsed(setupStart);
  const auto workStart=Clock::now();
  stamp(0); list->CopyBufferRegion(source.Get(),0,upload.Get(),0,pixels.size());
  transition(source.Get(),D3D12_RESOURCE_STATE_COPY_DEST,D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE); stamp(1);
  list->SetComputeRootSignature(root.Get()); list->SetPipelineState(pso.Get());
  UINT constants[]={count,width,height};
  list->SetComputeRoot32BitConstants(0,3,constants,0);
  list->SetComputeRootShaderResourceView(1,source->GetGPUVirtualAddress());
  list->SetComputeRootUnorderedAccessView(2,target->GetGPUVirtualAddress());
  for(UINT i=0;i<runs;++i) {
   stamp(2+2*i); list->Dispatch((count+255)/256,1,1);
   D3D12_RESOURCE_BARRIER b{}; b.Type=D3D12_RESOURCE_BARRIER_TYPE_UAV; b.UAV.pResource=target.Get();
   list->ResourceBarrier(1,&b); stamp(3+2*i);
  }
  stamp(queryCount-2);
  transition(target.Get(),D3D12_RESOURCE_STATE_UNORDERED_ACCESS,D3D12_RESOURCE_STATE_COPY_SOURCE);
  list->CopyBufferRegion(readback.Get(),0,target.Get(),0,outputBytes); stamp(queryCount-1);
  list->ResolveQueryData(queries.Get(),D3D12_QUERY_TYPE_TIMESTAMP,0,queryCount,timestamps.Get(),0);
  check(list->Close());
  ComPtr<ID3D12Fence> fence; check(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence)));
  HANDLE eventHandle=CreateEvent(nullptr,FALSE,FALSE,nullptr);
  if(!eventHandle) throw std::runtime_error("CreateEvent failed");
  ID3D12CommandList* lists[]={list.Get()}; queue->ExecuteCommandLists(1,lists); check(queue->Signal(fence.Get(),1));
  check(fence->SetEventOnCompletion(1,eventHandle));
  DWORD waitResult=WaitForSingleObject(eventHandle,30000); CloseHandle(eventHandle);
  if(waitResult!=WAIT_OBJECT_0) throw std::runtime_error("GPU completion timeout/failure");
  double batchCpuMs=elapsed(workStart);
  D3D12_RANGE readRange{0,outputBytes}; check(readback->Map(0,&readRange,&mapped));
  std::ofstream out(std::filesystem::path(argv[2]),std::ios::binary); out.write(static_cast<char*>(mapped),outputBytes);
  readback->Unmap(0,&noRead); out.close(); if(!out) throw std::runtime_error("Output write failed");
  D3D12_RANGE timeRange{0,queryCount*sizeof(UINT64)}; check(timestamps->Map(0,&timeRange,&mapped));
  auto values=static_cast<const UINT64*>(mapped);
  auto ms=[&](UINT a,UINT b) { return (values[b]-values[a])*1000.0/frequency; };
  std::vector<double> timings;
  for(UINT i=warmup;i<runs;++i) timings.push_back(ms(2+2*i,3+2*i));
  auto ordered=timings; std::sort(ordered.begin(),ordered.end());
  const size_t p50=(samples+1)/2-1, p95=(95*samples+99)/100-1;
  std::ofstream json{std::filesystem::path(argv[3])};
  json << "{\n  \"adapter\": \"" << utf8(adapterDesc.Description) << "\",\n"
       << "  \"dedicated_video_memory_bytes\": " << adapterDesc.DedicatedVideoMemory << ",\n"
       << "  \"pixels\": " << count << ",\n  \"record_mode\": \"" << utf8(mode.c_str()) << "\",\n"
       << "  \"input_bytes\": " << inputBytes << ",\n  \"output_bytes\": " << outputBytes << ",\n"
       << "  \"input_stride_bytes\": " << inputStride << ",\n  \"output_stride_bytes\": " << outputStride << ",\n";
  if(mode==L"rgba8") json << "  \"rgba_bytes\": " << inputBytes << ",\n";
  json
       << "  \"warmup_dispatches\": " << warmup << ",\n  \"measured_dispatches\": " << samples << ",\n"
       << "  \"gpu_dispatch_including_uav_barrier_p50_ms\": " << ordered[p50] << ",\n"
       << "  \"gpu_dispatch_including_uav_barrier_p95_ms\": " << ordered[p95] << ",\n"
       << "  \"gpu_upload_and_transition_ms\": " << ms(0,1) << ",\n"
       << "  \"gpu_readback_and_transition_ms\": " << ms(queryCount-2,queryCount-1) << ",\n"
       << "  \"batch_cpu_build_submit_wait_ms\": " << batchCpuMs << ",\n"
       << "  \"setup_including_shader_compile_ms\": " << setupMs << ",\n"
       << "  \"gpu_default_buffer_bytes\": " << inputBytes+outputBytes << ",\n"
       << "  \"dispatch_ms\": [";
  for(size_t i=0;i<timings.size();++i) { if(i) json << ','; json << timings[i]; }
  json << "]\n}\n"; json.close(); if(!json) throw std::runtime_error("JSON write failed");
  timestamps->Unmap(0,&noRead);
  std::cout << utf8(adapterDesc.Description) << ": " << count << " pixels, GPU p50=" << ordered[p50] << " ms; p95=" << ordered[p95] << " ms\n";
  return 0;
 } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
